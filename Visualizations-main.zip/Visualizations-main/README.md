# data_visuals_page
Data visualization page for Enigma Solutions

This code contains a Dash app that uses data from a MongoDB to generate visualizations for gelocation and N-factor data.
